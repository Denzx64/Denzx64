/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Ghost [ Develover Sc ]  
- WannOFFC [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( Nama Mu )
*/

const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const axios = require('axios');

const settings = require('./settings'); 
const Token = settings.token;
const owner = settings.adminId;
const ownerutama = settings.adminId1;
const adminfile = 'adminID.json';
const premiumUsersFile = 'premiumUsers.json';
try {
    premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
} catch (error) {
    console.error('Error reading premiumUsers file:', error);
}
const bot = new TelegramBot(Token, { polling: true });
try {
    adminUsers = JSON.parse(fs.readFileSync(adminfile));
} catch (error) {
    console.error('Error reading adminUsers file:', error);
}

const zones = {
    '5d00f56aee3afd9cc4e0666bc8f23746': 'kedai-panel.my.id',
    'a476ffcf9243c44a02220f184da527e8': 'mypanell.biz.id',
    '891a2e5d4ac5b3db4fbcef8d9088ad38': 'cpanel-vip.my.id',
    '4d44fcf2de2bbbad2f07d17ec5912703': 'prv-panelwann.my.id',
    '1f560490c2626dc370e6ac28cd2129e3': 'roomdigital.site',
    '03f3569e809aa63eb40d842af3ddb523': 'panelprivv.xyz',
    '5f4a582dd80c518fb2c7a425256fb491': 'tokopanellku.my.id',
    '15b97d8a42af1c00a70070e577ce7301': 'kiospanell.my.id',
    '5e9c879001b63885301e77f48c3d7e58': 'panellshop.biz.id',
    '2feafa10ec4054af7cb04b18515013e5': 'tokopanellmurah.my.id',
    '2dc001900c742f289eef7dbae7ab784b': 'bisnispanel.my.id',
    'fb953c98b23bc7619f0e54701db07878': 'xmartpanel.my.id',
    '77c6588b3b36e74d07538e62ef91d6ba': 'tokopanel.biz.id',
    '4049d75623d46e90d616fdf878a5ed84': 'store-panel.biz.id',
    '8080d914883ed0b9e17d281f593df945': 'sellerpanel.biz.id',
    '6c4af9293eed7ea87c94d8effe5f2de2': 'panellprivate.my.id',
    'cada0ecef8f1e8d904435d469aef1b05': 'mypanel.my.id',
    'd318f96a6327c5340d136415e860f545': 'kangpanel.biz.id',
    '8132a433dc4eea653e38e168f2f45fc0': 'jasapanel.my.id',
    '5024bc4a02924cf69ddf4dfa6ee96069': 'dewapanel.my.id',
    '98264c6c53c5bc9080230b077422d748': 'adminpanel.biz.id',
    '9b28f4ad0f06b36dd94cc56b01efc19a': 'plerkuda.my.id',
    '2bb49b2de0cbf75c0462ed90d7d333e1': 'cafegt.my.id',
    '9ddbf1836c0a5a70de3d915d3b81e335': 'storemurah.my.id',
    'fa2790178cc13b4b23425274cf2540a3': 'panellshop.my.id',
    '20fa5bf6edca2ab185be760c15ada53e': 'paneldigital.my.id',
    '016ec3d7a8a5f0c3d2c56ee1980f3f2a': 'cpanell-net.biz.id',
    '310d6626c40e74bd9d99ed7ba80c6ee2': 'srvelite.biz.id',
    '5022dc34d87e96fcf11f9e35360548b1': 'wnn.my.id',
  '3e6ec90ce998dcbc24a78fcfc6ea4c07': 'panelelite.biz.id'
};

const apiTokens = {
    '5d00f56aee3afd9cc4e0666bc8f23746 ': 'mjR4BdiOo6aFO3uPl8BTgZIgOMH3asLbgVsOpEfO',
    'a476ffcf9243c44a02220f184da527e8': 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ',
    '891a2e5d4ac5b3db4fbcef8d9088ad38': 'V2BCJ-jhHXQlkN5-_Jv-CuXEtJbLT9fo7NWAlMK2',
    '4d44fcf2de2bbbad2f07d17ec5912703': '5yJvLdRfC0CPI-xBAY59k3WJIpWe-R6tvmR_-8C3',
    '1f560490c2626dc370e6ac28cd2129e3': '8iaeBGtHb4oR33bFXP-G4upa2O9kJPQw5TGawdyJ',
    '03f3569e809aa63eb40d842af3ddb523': 'kLS7qdEt9zuC9UJr2u5ok5LsPaKKk0p0vuuTgmEo',
    '5f4a582dd80c518fb2c7a425256fb491': 'iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby',
    '15b97d8a42af1c00a70070e577ce7301': 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ',
    '5e9c879001b63885301e77f48c3d7e58': 'yphLnXT8CL6t6NO7HozsTyqCO6_CIgbb8I7Nudwz',
    '2feafa10ec4054af7cb04b18515013e5': '8WA6BgIuvFO5AL3xJZf3bsM0ts8aIZiFbxj90icK',
    '2dc001900c742f289eef7dbae7ab784b': 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ*',
    'fb953c98b23bc7619f0e54701db07878': 'ycq92Hz_KkhfnVPp-Zo83AtKIUaErg1UmkHRckm-',
    '77c6588b3b36e74d07538e62ef91d6ba': 'SgON4r6174fMe3h3B9wyP3caEtwUIfnVuNvSpl1k',
    '4049d75623d46e90d616fdf878a5ed84': 'qwAWquCm1cqKEzZnZUEuAbfFq3PCOLleQZifxPog',
    '8080d914883ed0b9e17d281f593df945': 'BP2uUPgVfrM4pHW_ivo2AawAyiLqOMYoLYyS2BF7',
    '6c4af9293eed7ea87c94d8effe5f2de2': 'fxR0JgMIVwd0wvGIeBTymygdSMx1yNAN12lN8ure',
    'cada0ecef8f1e8d904435d469aef1b05': '54kx4yvi3CBqomC99WSaqZo9tbxHoe9U-ncBIVMx',
    'd318f96a6327c5340d136415e860f545': 'RTe9hBdh_-nt0wzOvYN183JyQC011yaiodQ7Po1b',
    '8132a433dc4eea653e38e168f2f45fc0': '33F2gfJ0cEoLv4NlEqLYGd6Ahc5_dzyUH_ClKuX_',
    '5024bc4a02924cf69ddf4dfa6ee96069': 'OajJ0jtCB0FTFwfdiTB_ktzNKFWAmsENFdlE4Hvd',
    '98264c6c53c5bc9080230b077422d748': '1W9IHC9mLAKj8hQaMjczy0gA3Of7kPjJ3gAvTlnZ',
    '9b28f4ad0f06b36dd94cc56b01efc19a': 'bMiZlOhkSzozUq1jMLO5bk4OeZr0GllyVtVWX1F4',
    '2bb49b2de0cbf75c0462ed90d7d333e1': 'lZ0XMXdnwp2L1DsI3f8frkPwvkQ6ENee2PnAfOsY',
    '9ddbf1836c0a5a70de3d915d3b81e335': '-qz5IvvImeSmnYgf6AI9C4PTJ9qpFmBtaAudHhZ2',
    'fa2790178cc13b4b23425274cf2540a3': 'DSRw23oEmsVU-7OzObRdYnJUVQy8vOed0otx39IO',
    '20fa5bf6edca2ab185be760c15ada53e': 'fHm1j22HLHMcW6zGGr-W_pL8O6__tl5XTRbsSLTd',
    '016ec3d7a8a5f0c3d2c56ee1980f3f2a': 'vzZ6L5IdH6-RJSv_hPhrONne9sXp6NJ5uloK1PI-',
    '310d6626c40e74bd9d99ed7ba80c6ee2': '1A9KgIMgbt0UaGd1x7dVjtw4y00HUS2MLG4QVGNY',
    '5022dc34d87e96fcf11f9e35360548b1': 'liomOzxwPzmMy3SdyxFkheCJ25ETltWzTFdYsDR3',
    '3e6ec90ce998dcbc24a78fcfc6ea4c07': 'Nn2b3QfE91c1OG9SplHkyFZcxix3F6C-bXlrWKxj'
};
function getRuntime(startTime) {
    const uptime = process.uptime();
    const hours = Math.floor(uptime / 3600);
    const minutes = Math.floor((uptime % 3600) / 60);
    const seconds = Math.floor(uptime % 60);
    return `${hours} Jam ${minutes} Menit ${seconds} Detik`;
}
const nama = '𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨';
const author = '𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝘿𝙚𝙫𝙚𝙡𝙤𝙥𝙚𝙧 べ₪';
const donasiData = {
   pesan: 'BOT BERHASIL NYALA 🤓\nJANGAN BAGIKAN SC INI SECARA GRATIS !!, KETAHUAN? DENDA 50K\nOWNER SCRIPT @WannOFFC08'
};
bot.sendMessage(ownerutama,
`NAMA: ${nama}\nPESAN: ${donasiData.pesan}`);
// Informasi waktu mulai bot
const startTime = Date.now();
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// start
bot.onText(/\/start/, (msg) => {
    const chatId = msg.chat.id;
    const startTime = Date.now();
    const menuText = `
┏━━ 𝗜𝗡𝗙𝗢 𝗠𝗘𝗡𝗨 ━⊜

 ∘ 🤖 Nama Bot: ${nama}
 ∘ 👤 Author Bot: ${author}
 ∘ ⏲️ Runtime: ${getRuntime(startTime)}

┗━━━━━━━━━━━━━━

┏━━ 𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 ━⊜
 ∘ /cekid
 ∘ /addowner
 ∘ /delowner
 ∘ /addprem
 ∘ /delprem 
 © 𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨
┗━━━━━━━━━━━━━━━━`;
// Event listener for button 'My Profil'
bot.on('callback_query', (callbackQuery) => {
  if (callbackQuery.data === 'myprofil') {
    bot.answerCallbackQuery(callbackQuery.id);
    bot.sendMessage(callbackQuery.from.id, 'Hallo, saya adalah My Profil. Bot Ini Milik @WannOFFC08');
  }
});
// Event listener for button 'Start'
bot.on('callback_query', (callbackQuery) => {
    if (callbackQuery.data === 'start') {
        const chatId = callbackQuery.message.chat.id;
        const startTime = Date.now();

        const menuText = `
┏━━ 𝗜𝗡𝗙𝗢 𝗠𝗘𝗡𝗨 ━⊜

 ∘ 🤖 Nama Bot: ${nama}
 ∘ 👤 Author Bot: ${author}
 ∘ ⏲️ Runtime: ${getRuntime(startTime)}

┗━━━━━━━━━━━━━━

┏━━ 𝗟𝗜𝗦𝗧 𝗠𝗘𝗡𝗨 ━⊜
 ∘ /cekid
 ∘ /addowner
 ∘ /delowner
 ∘ /addprem
 ∘ /delprem 
 © 𝙒𝙖𝙣𝙣𝙊𝙁𝙁𝘾 χ 𝙂𝙝𝙤𝙨𝙩𝙓𝙈𝙤𝙙𝙨
┗━━━━━━━━━━━━━━━━`;
 const message = menuText;
 const keyboard = {
            reply_markup: {
                inline_keyboard: [
                    [{ text: '📓 Listdomain', callback_data: 'listdomain' }, { text: '🙋‍♂️ My Profil', callback_data: 'myprofil' }],

                ]
            }
        };
        bot.answerCallbackQuery(callbackQuery.id);
        bot.editMessageText(message, {
            chat_id: chatId,
            message_id: callbackQuery.message.message_id,
            reply_markup: keyboard,
            parse_mode: 'Markdown'
        });
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// listdomain
const message = menuText;
const keyboard = {
  reply_markup: {
  inline_keyboard: [
  [{ text: '📓 Listdomain', callback_data: 'listdomain' }, { text: '🙋‍♂️ My Profil', callback_data: 'myprofil' }],

            ]
        }
    }; 
    bot.sendMessage(chatId, message, keyboard);
});
bot.on('callback_query', (callbackQuery) => {
  if (callbackQuery.data === 'listdomain') {
    bot.answerCallbackQuery(callbackQuery.id);
    const ramListMessage = "┏━━ 𝐈𝐍𝐅𝐎 𝐌𝐄𝐍𝐔 ━⊜\n ∘ 𝘓𝘢𝘺𝘢𝘯𝘢𝘯 𝘊𝘋𝘕 : 𝘊𝘓𝘖𝘜𝘋𝘍𝘓𝘈𝘙𝘌\n ∘ 𝘛𝘰𝘵𝘢𝘭 𝘋𝘰𝘮𝘢𝘪𝘯 : 30\n ∘ 𝘛𝘰𝘵𝘢𝘭 𝘋𝘰𝘮𝘢𝘪𝘯 On : 30\n┗━━━━━━━━━━━━━━\n ∘ DISARANKAN UNTUK PTERODACLTY 🚨\n┗━━━━━━━━━━━━━━━━━\n\n∘ /1 kedai-panel.my.id\n∘ /2 mypanell.biz.id\n∘ /3 cpanel-vip.my.id (khusus cpanel)\n∘ /4 prv-panelwann.my.id\n∘ /5 roomdigital.site\n∘ /6 panelprivv.xyz\n∘ /7 tokopanellku.my.id\n∘ /8 kiospanell.my.id\n∘ /9 panellshop.biz.id\n∘ /10 tokopanellmurah.my.id\n∘ /11 bisnispanel.my.id\n∘ /12 xmartpanel.my.id\n∘ /13 tokopanel.biz.id\n∘ /14 store-panel.biz.id\n∘ /15 sellerpanel.biz.id\n∘ /16 panellprivate.my.id\n∘ /17 mypanel.my.id\n∘ /18 kangpanel.biz.id\n∘ /19 jasapanel.my.id\n∘ /20 dewapanel.my.id\n∘ /21 adminpanel.biz.id\n∘ /22 plerkuda.my.id\n∘ /23 cafegt.my.id\n∘ /24 storemurah.my.id\n∘ /25 panellshop.my.id\n∘ /26 paneldigital.my.id\n∘ /27 cpanell-net.biz.id (khusus cpanel)\n∘ /28 srvelite.biz.id\n∘ /29 wnn.my.id\n∘ /30 panelelite.biz.id\n▬▭▬▭▬▭▬▭▬▭▬▭▬\n NOTE: \n - DILARANG UNTUK DI PAKAI UNTUK WHM/CPANEL\n - DILARANG DDOS SESAMA RESSELER\n - CARA BUAT KETIK CONTOH : /NO SUBDO IP\nCONTOH : /1 wann 62.283.272xxx";
    bot.editMessageText(ramListMessage, {
      chat_id: callbackQuery.message.chat.id,
      message_id: callbackQuery.message.message_id,
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Kembali ke Menu Start', callback_data: 'start' }]
        ]
      }
    });
  }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// Handle command '/donasi'
bot.onText(/\/donasi/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '1344553362'; // Ganti dengan ID pemilik bot 
    const text12 = `Hi @${sender} 👋

Jika Ingin Donasi Silahkan Scan Qris Di Atas 😁✌️
Owner @WannOFFC08`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/WannOFFC08/buy_panel' }, { text: '👤 Buy Admin', url: 'https://t.me/WannOFFC08/buyadminp & ptpanel' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/WannOFFC08/buyvps' }]
            ]
        }
    }
bot.sendPhoto(chatId, settings.qris, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// Handle command '/cekid'
bot.onText(/\/cekid/, (msg) => {
    const chatId = msg.chat.id;
    const sender = msg.from.username;
    const owner = '1344553362'; // Ganti dengan ID pemilik bot 
    const text12 = `Hi @${sender} 👋
    
👤 From ${msg.from.id}
  └🙋🏽 kamu
  
 ID Telegram Anda: ${msg.from.id}
 Full Name Anda :@${sender}

🙏🏼 Permisi, bot akan pergi secara otomatis.
 Developer : @WannOFFC08`;
    const keyboard = {
        reply_markup: {
            inline_keyboard: [
                [{ text: '🖥️ Buy Panel', url: 'https://t.me/WannOFFC08/buy_panel' }, { text: '👤 Buy Admin', url: 'https://t.me/WannOFFC08/buyadminp & ptpanel' }],
                [{ text: '🇲🇨 Buy Vps', url: 'https://t.me/WannOFFC08/buyvps' }]
            ]
        }
    };
    bot.sendPhoto(chatId, settings.pp, { caption: text12, parse_mode: 'Markdown', reply_markup: keyboard });
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addprem
bot.onText(/\/addprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!premiumUsers.includes(userId)) {
            premiumUsers.push(userId);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delprem
bot.onText(/\/delprem (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];  
    if (msg.from.id.toString() === owner) {
        const index = premiumUsers.indexOf(userId);
        if (index !== -1) {
            premiumUsers.splice(index, 1);
            fs.writeFileSync(premiumUsersFile, JSON.stringify(premiumUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from premium users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not a premium user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// addowner
bot.onText(/\/addowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        if (!adminUsers.includes(userId)) {
            adminUsers.push(userId);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been added to admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is already an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// delowner
bot.onText(/\/delowner (.+)/, (msg, match) => {
    const chatId = msg.chat.id;
    const userId = match[1];
    
    if (msg.from.id.toString() === owner) {
        const index = adminUsers.indexOf(userId);
        if (index !== -1) {
            adminUsers.splice(index, 1);
            fs.writeFileSync(adminfile, JSON.stringify(adminUsers));
            bot.sendMessage(chatId, `User ${userId} has been removed from admin users.`);
        } else {
            bot.sendMessage(chatId, `User ${userId} is not an admin user.`);
        }
    } else {
        bot.sendMessage(chatId, 'Only the owner can perform this action.');
    }
});
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 1
bot.onText(/\/1 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '5d00f56aee3afd9cc4e0666bc8f23746', 'mjR4BdiOo6aFO3uPl8BTgZIgOMH3asLbgVsOpEfO');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 2
bot.onText(/\/2 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'a476ffcf9243c44a02220f184da527e8', 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain2 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 3
bot.onText(/\/3 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '891a2e5d4ac5b3db4fbcef8d9088ad38', 'V2BCJ-jhHXQlkN5-_Jv-CuXEtJbLT9fo7NWAlMK2');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain3 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 4
bot.onText(/\/4 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '4d44fcf2de2bbbad2f07d17ec5912703', '5yJvLdRfC0CPI-xBAY59k3WJIpWe-R6tvmR_-8C3');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain4 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 5
bot.onText(/\/5 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
      const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah hanya untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Hubungi Admin', url: settings.adminUrl }
                    ]
                ]
            }
        });
        return;
    }
    
    const response = await createSubdomain(subdomain, ip, '1f560490c2626dc370e6ac28cd2129e3', '8iaeBGtHb4oR33bFXP-G4upa2O9kJPQw5TGawdyJ');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain5 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 6
bot.onText(/\/6 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
      const adminUsers = JSON.parse(fs.readFileSync(adminfile));
    const isAdmin = adminUsers.includes(String(msg.from.id));

    if (!isAdmin) {
        bot.sendMessage(chatId, 'Perintah hanya untuk Owner, Hubungi Admin Saya Untuk Menjadi Owner atau Users Premium...', {
            reply_markup: {
                inline_keyboard: [
                    [
                        { text: 'Hubungi Admin', url: settings.adminUrl }
                    ]
                ]
            }
        });
        return;
    }
    const response = await createSubdomain(subdomain, ip, '03f3569e809aa63eb40d842af3ddb523', 'kLS7qdEt9zuC9UJr2u5ok5LsPaKKk0p0vuuTgmEo');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain6 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 7
bot.onText(/\/7 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '5f4a582dd80c518fb2c7a425256fb491', 'iQbJQgfe6kTyEfdOy_EV8UAHKj80VgQg4t6rTjby');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain7 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 8
bot.onText(/\/8 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '15b97d8a42af1c00a70070e577ce7301', 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain8 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 9
bot.onText(/\/9 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '5e9c879001b63885301e77f48c3d7e58', 'yphLnXT8CL6t6NO7HozsTyqCO6_CIgbb8I7Nudwz');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain9 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 10
bot.onText(/\/10 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '2feafa10ec4054af7cb04b18515013e5', '8WA6BgIuvFO5AL3xJZf3bsM0ts8aIZiFbxj90icK');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain10 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 11
bot.onText(/\/11 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '2dc001900c742f289eef7dbae7ab784b', 'RsbJAI6X7s7bPEj23R7sf28cqHibApP1EBSoF4FZ');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain11 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 12
bot.onText(/\/12 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'fb953c98b23bc7619f0e54701db07878', 'ycq92Hz_KkhfnVPp-Zo83AtKIUaErg1UmkHRckm-');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain12 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 13
bot.onText(/\/13 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '77c6588b3b36e74d07538e62ef91d6ba', 'SgON4r6174fMe3h3B9wyP3caEtwUIfnVuNvSpl1k');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain13 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 14
bot.onText(/\/14 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '4049d75623d46e90d616fdf878a5ed84', 'qwAWquCm1cqKEzZnZUEuAbfFq3PCOLleQZifxPog');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain14 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 15
bot.onText(/\/15 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '8080d914883ed0b9e17d281f593df945', 'BP2uUPgVfrM4pHW_ivo2AawAyiLqOMYoLYyS2BF7');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain15 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 16
bot.onText(/\/16 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '6c4af9293eed7ea87c94d8effe5f2de2', 'fxR0JgMIVwd0wvGIeBTymygdSMx1yNAN12lN8ure');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain16 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 17
bot.onText(/\/17 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'cada0ecef8f1e8d904435d469aef1b05', '54kx4yvi3CBqomC99WSaqZo9tbxHoe9U-ncBIVMx');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain17 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 18
bot.onText(/\/18 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'd318f96a6327c5340d136415e860f545', 'RTe9hBdh_-nt0wzOvYN183JyQC011yaiodQ7Po1b');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain18 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 19
bot.onText(/\/19 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '8132a433dc4eea653e38e168f2f45fc0', '33F2gfJ0cEoLv4NlEqLYGd6Ahc5_dzyUH_ClKuX_');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain19 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 20
bot.onText(/\/20 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '5024bc4a02924cf69ddf4dfa6ee96069', 'OajJ0jtCB0FTFwfdiTB_ktzNKFWAmsENFdlE4Hvd');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain20 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 21
bot.onText(/\/21 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '98264c6c53c5bc9080230b077422d748', '1W9IHC9mLAKj8hQaMjczy0gA3Of7kPjJ3gAvTlnZ');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain21 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 22
bot.onText(/\/22 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '9b28f4ad0f06b36dd94cc56b01efc19a', 'bMiZlOhkSzozUq1jMLO5bk4OeZr0GllyVtVWX1F4');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain22 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 23
bot.onText(/\/23 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '2bb49b2de0cbf75c0462ed90d7d333e1', 'lZ0XMXdnwp2L1DsI3f8frkPwvkQ6ENee2PnAfOsY');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain23 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 24
bot.onText(/\/24 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '9ddbf1836c0a5a70de3d915d3b81e335', '-qz5IvvImeSmnYgf6AI9C4PTJ9qpFmBtaAudHhZ2');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain24 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 25
bot.onText(/\/25 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, 'fa2790178cc13b4b23425274cf2540a3', 'DSRw23oEmsVU-7OzObRdYnJUVQy8vOed0otx39IO');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain25 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 26
bot.onText(/\/26 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '20fa5bf6edca2ab185be760c15ada53e', 'fHm1j22HLHMcW6zGGr-W_pL8O6__tl5XTRbsSLTd');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain26 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 27
bot.onText(/\/27 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '016ec3d7a8a5f0c3d2c56ee1980f3f2a', 'vzZ6L5IdH6-RJSv_hPhrONne9sXp6NJ5uloK1PI-');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain27 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 28
bot.onText(/\/28 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '310d6626c40e74bd9d99ed7ba80c6ee2', '1A9KgIMgbt0UaGd1x7dVjtw4y00HUS2MLG4QVGNY');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain28 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};
//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 29
bot.onText(/\/29 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '5022dc34d87e96fcf11f9e35360548b1', 'liomOzxwPzmMy3SdyxFkheCJ25ETltWzTFdYsDR3');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain29 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};

//▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰▰//
// domain 30
bot.onText(/\/30 (.+) (.+)/, async (msg, match) => {
    const chatId = msg.chat.id;
    const subdomain = match[1];
    const ip = match[2];
    const userId = msg.from.id;
    const premiumUsers = JSON.parse(fs.readFileSync(premiumUsersFile));
  const isPremium = premiumUsers.includes(String(msg.from.id));
  if (!isPremium) {
    bot.sendMessage(chatId, 'Perintah Hanya Untuk Users Premium, Hubungi Admin Saya Untuk Menjadi Users Premium...', {
      reply_markup: {
        inline_keyboard: [
          [
            { text: 'HUBUNGI ADMIN', url: 'https://t.me/WannOFFC08' }
          ]
        ]
      }
    });
    return;
  }
    const response = await createSubdomain(subdomain, ip, '3e6ec90ce998dcbc24a78fcfc6ea4c07', 'Nn2b3QfE91c1OG9SplHkyFZcxix3F6C-bXlrWKxj');
    if (response.success) {
        bot.sendMessage(chatId, response.message);
    } else {
        bot.sendMessage(chatId, 'Failed to create subdomain.');
    }
});


const createSubdomain30 = async (subdomain, ipAddress, zoneId, apiToken) => {
    try {
        const url = `https://api.cloudflare.com/client/v4/zones/${zoneId}/dns_records`;
        const data = {
            type: 'A',
            name: `${subdomain}.${zones[zoneId]}`,
            content: ipAddress,
            ttl: 0,
            proxied: false
        };
        const headers = {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${apiToken}`
        };

        const response = await axios.post(url, data, { headers: headers });
        return { success: true, message: `Subdomain ${subdomain}.${zones[zoneId]} created successfully with IP ${ipAddress}.` };
    } catch (error) {
        console.error(error);
        return { success: false, message: 'Failed to create subdomain.' };
    }
};


module.exports = { createSubdomain };