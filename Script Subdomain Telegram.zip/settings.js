/*
• Base Ori GhostXmods X WannOFFC
Penting ‼️

Hapus Bagian/Teks Ini? Masuk Neraka Paling Bawah

Script Ini Murni Bikinan Sendiri, Saya Hanya Sekedar Kroco Penghuni Inti Bumi.

Thanks To :                                
- Allah Swt 
- Nabi Muhammad Saw         
- My Parents       
- Ghost [ Develover Sc ]  
- WannOFFC [ Support ]
- Pengguna Bot Yang Selalu Support

• Recode By ( Nama Mu )
*/

const settings = {
  token: '6836624850:AAHcyyXZQDmrBIbmduZ1_gyau2rg6hj4snI', //Token Bot
  adminId1: '1344553362', //Jangan Di Detele Nanti Eror !!
  adminId: '1344553362', //ID Kalian
  groupId: '-1001632978930',
  urladmin: 'https://t.me/WannOFFC08',
  menuUrl: 'https://t.me/WannOFFC08',
  groupUrl: 'https://t.me/RoomPublicWann',
  chanelUrl: 'https://t.me/TestiByWann',
  pp: 'https://telegra.ph/file/8ef2d072f8c68f120d18d.jpg',
  ppp: 'https://telegra.ph/file/8ef2d072f8c68f120d18d.jpg',
   qris: 'https://telegra.ph/file/e24baed2df0ed8e7967fe.jpg',
  adminteks: 'Hai Saya Bot Subdo Milik WannOFFC !!\nAda Yang Dapat Saya Bantu?\nIngin Membeli Script/Premium? Pv @WannOFFC'
};

module.exports = {
  ...settings,
  domain: 'kiicodeofficial.my.id',
  apikeys: {
    blackbox: '3wezRae6AZ',
    openai: '3wezRae6AZ'
  }
};